
function [ ResultHL, ResultAP, ResultOE, ResultRL, ResultCV, ResultAUC ] = LLSF_adaptive_validate( train_data, train_target, oldOptmParameter)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% tune the best parameters for LLSF by crossvalidation
% Input
%   - train_data            : n by d data matrix
%   - trian_target          : n by l lable matrix
%   - oldOptmParameter      : initilization parameter
%
% Output
%   - BestParameter         : a structral variable with searched paramters,
%                             ie. alpha, beta, and gamma
%   - BestResult            : best result on the training data
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    num_train             = size(train_data,1);
    randorder             = randperm(num_train);
    
    optmParameter         = oldOptmParameter;
    
    alpha_searchrange     = oldOptmParameter.alpha_searchrange;
    beta_searchrange      = oldOptmParameter.beta_searchrange;
    gamma_searchrange     = oldOptmParameter.gamma_searchrange;
    lambda_searchrange     = oldOptmParameter.lambda_searchrange;
    misRate = 0.3;   %%%
   % BestResult = zeros(16,1);
    num_cv = 5;
    index = 1;
    total = length(alpha_searchrange)*length(beta_searchrange)*length(gamma_searchrange)*length(lambda_searchrange);
    for i=1:length(alpha_searchrange) % alpha
        for j=1:length(beta_searchrange) % beta
            for k = 1:length(gamma_searchrange) % gamma
                for l = 1:length(lambda_searchrange) %lambda   
                    fprintf('\n-   %d-th/%d: search parameter alpha and beta for LLSF, alpha = %f, beta = %f, and gamma = %f',index, total, alpha_searchrange(i), beta_searchrange(j), gamma_searchrange(k));
                    index = index + 1;
                    optmParameter.alpha   = alpha_searchrange(i); % label correlation
                    optmParameter.beta    = beta_searchrange(j);  % sparsity
                    optmParameter.gamma   = gamma_searchrange(k); % {0.01, 0.1}
                    optmParameter.lambda   = lambda_searchrange(l); % 

                    optmParameter.maxIter           = 100;
                    optmParameter.minimumLossMargin = 0.01;
                    optmParameter.outputtempresult  = 0;
                    optmParameter.drawConvergence   = 0;

                    cvResult = zeros(16,num_cv);  %%
                    for cv = 1:num_cv
                        [cv_train_data,cv_train_target,cv_test_data,cv_test_target ] = generateCVSet( train_data,train_target',randorder,cv,num_cv);
                        [model_LLSF]  = LLSF( cv_train_data, cv_train_target,optmParameter);
                        Outputs     = (cv_test_data*model_LLSF)';
                        Pre_Labels  = round(Outputs);Pre_Labels  = (Pre_Labels >= 1); Pre_Labels  = double(Pre_Labels);
                        %cvResult      = cvResult + EvaluationAll(Pre_Labels,Outputs,cv_test_target');
                        tmpResult = EvaluationAll(Pre_Labels,Outputs,cv_test_target');
                        cvResult(:,cv) = cvResult(:,cv) + tmpResult;
                    end
                    Avg_Result = zeros(16,2);
                    Avg_Result(:,1)=mean(cvResult,2);
                    Avg_Result(:,2)=std(cvResult,1,2);
                    %cvResult = cvResult./num_cv;    
                    ResultHL(i,1)=Avg_Result(1,1);
                    ResultAP(i,1) =Avg_Result(12,1);
                    ResultOE(i,1) =Avg_Result(13,1);
                    ResultRL(i,1) =Avg_Result(14,1);
                    ResultCV(i,1) =Avg_Result(15,1);
                    ResultAUC(i,1)=Avg_Result(16,1);
                 
                 %if optmParameter.bQuiet == 0
                 %    PrintResults(Result)
                 %end
                 %r = IsBetterThanBefore(BestResult,Result);
                 %if r == 1
                 %   BestResult = Result;
                 %   PrintResults(Result);
                 %   BestParameter = optmParameter;
                 %end
                end
            end
        end
    end
end


function r = IsBetterThanBefore(Result,CurrentResult)
% 1 HammingLoss
% 2 ExampleBasedAPCCuracy
% 3 ExampleBasedPrecision
% 4 ExampleBasedRecall
% 5 ExampleBasedFmeasure
% 6 SubsetAPCCuracy
% 7 LabelBasedAPCCuracy
% 8 LabelBasedPrecision
% 9 LabelBasedRecall
% 10 LabelBasedFmeasure
% 11 MicroF1Measure
% 12 Average_Precision
% 13 OneError
% 14 RankingLoss
% 15 Coverage
% 16 AUC
%  the combination of Accuracy, F1, Macro F1 and Micro F1. Of course, any evaluation metrics or the combination of them can be used.

    a = 1-CurrentResult(1,1) + CurrentResult(12,1)  + 1-CurrentResult(13,1) + 1-CurrentResult(14,1) ;
    b = 1-Result(1,1) + Result(12,1) + 1-Result(13,1) + 1-Result(14,1);

    if a > b
        r =1;
    else
        r = 0;
    end
end
